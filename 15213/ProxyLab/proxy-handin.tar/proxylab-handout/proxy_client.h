#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>

int forward_request();
int create_connection();
void get_response();
