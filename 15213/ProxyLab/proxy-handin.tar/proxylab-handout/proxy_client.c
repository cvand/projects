#include "proxy_client.h"

int forward_request() {

}

int create_connection() {

}

void get_response() {

}
